package com.example.project11;


import com.google.android.maps.MapActivity;
import com.google.android.maps.MapView;
import com.google.android.maps.MapController;
import com.google.android.maps.GeoPoint;
import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.Geocoder;
import android.location.Address;

import com.google.android.maps.Overlay;

import android.graphics.Canvas;
import android.graphics.Point;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.util.List;
import java.util.Locale;
import java.io.IOException;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends MapActivity {
    /** Called when the activity is first created. */

	private LocationManager locationManager;
    private LocationListener locationListener;
	@Override
	public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new AsyncTask<Void, Void, String>() {


            @Override
            protected String doInBackground(Void... params) {
                WebServiceRequestManager manager = new WebServiceRequestManager();
                return manager.getMethod("http://50.57.145.165:8080/FirstGroupRailApps/jservices/rest/a/destinationdashboard?crsCode=add");
            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);
                System.out.println("Respose : " + result);
                hideProgressDialog();
            }
        }.execute();
    }

    public void showProgressDialog(final String msg) {

        runOnUiThread(new Runnable() {
            public void run() {
                if (progress == null || !progress.isShowing()) {
                    progress = ProgressDialog.show(MainActivity.this, "", msg);
                }
            }
        });
    }

    public void hideProgressDialog() {
        runOnUiThread(new Runnable() {

            @Override
            public void run() {
                try {
                    if (progress.isShowing())
                        progress.dismiss();
                } catch (Throwable e) {

                }
            }
        });
    }
        Button btn=(Button) findViewById(R.id.button1);
        
        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);    
        
        locationListener = new GPSLocationListener();
        
        locationManager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER, 
            0, 
            0, 
     
            locationListener);
        
        
	}
       
 
	@Override
    protected boolean isRouteDisplayed() {
        return false;
    }
    
    public class GPSLocationListener implements LocationListener 
    {
        @Override
        public void onLocationChanged(Location location) {
            if (location != null) {
                GeoPoint point = new GeoPoint(
                        (int) (location.getLatitude() * 1E6), 
                        (int) (location.getLongitude() * 1E6));
                
                /* Toast.makeText(getBaseContext(), 
                        "Latitude: " + location.getLatitude() + 
                        " Longitude: " + location.getLongitude()+ "Speed"+ location.getSpeed(), 
                        Toast.LENGTH_SHORT).show();*/
                           float speed=location.getSpeed();
                           int sped=(int)speed;
                           if(sped>=40){
                           speedlimit(speed);
                           }
          			
         //       String address = ConvertPointToLocation(point);
          //      Toast.makeText(getBaseContext(), address, Toast.LENGTH_SHORT).show();

            }
        }
        
        private void speedlimit(float speed) {
			// TODO Auto-generated method stub
        		
        	
		}

	/*	public String ConvertPointToLocation(GeoPoint point) {   
        	String address = "";
            Geocoder geoCoder = new Geocoder(
                    getBaseContext(), Locale.getDefault());
            try {
                List<Address> addresses = geoCoder.getFromLocation(
                	point.getLatitudeE6()  / 1E6, 
                    point.getLongitudeE6() / 1E6, 1);
	 
		        if (addresses.size() > 0) {
		            for (int index = 0; index < addresses.get(0).getMaxAddressLineIndex(); index++)
		            	address += addresses.get(0).getAddressLine(index) + " ";
		        }
            }
            catch (IOException e) {                
                e.printStackTrace();
            }   
            
            return address;
        } */

        @Override
        public void onProviderDisabled(String provider) {
        }

        @Override
        public void onProviderEnabled(String provider) {
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
        }
    }
    
    
}